<!DOCTYPE html>
<html>
<body>

<?php
$txt1 = "Bahasa PHP susah banget";
$txt2 = "Susah Banget";

echo "<h2>$txt1</h2>";
echo "<p> Bahasa PHP itu $txt2</p>";
?> 

</body>
</html>
