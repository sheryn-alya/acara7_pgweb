<!DOCTYPE html>
<html>
<body>

<?php 
$x = "Hai Ganteng";
$y = 'Hai Cantik';

var_dump($x);
echo "<br>"; 
var_dump($y);
?>

</body>
</html>
