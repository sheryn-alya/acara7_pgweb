<!DOCTYPE html>
<html>
<body>

<?php
$boyfriend = array("Sehun", "Kai", "Chanyeol");  
$flag = array("Yellow", "brown", "orange"); // untuk pembuatan table bagian bendera atau warna

echo "<table border='1' cellpadding='10' cellspacing='0'>";
echo "<tr><th>Bestie dan pacar ku</th><th>Flag</th></tr>";  // Baris judul

for ($i = 0; $i < count($boyfriend); $i++) {
    echo "<tr><td>" . $boyfriend[$i] . "</td><td>" . $flag[$i] . "</td></tr>";
}
echo "</table>";
?>

</body>
</html>