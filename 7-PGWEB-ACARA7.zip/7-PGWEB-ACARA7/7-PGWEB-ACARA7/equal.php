<!DOCTYPE html>
<html>
<body>

<?php
$x = 540;  
$y = "540";

var_dump($x == $y); // returns true because values are equal
?>  

</body>
</html>
