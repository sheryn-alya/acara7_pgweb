<!DOCTYPE html>
<html>
<body>

<?php
$x = 456;
$x %= 10;

echo $x;
?>  

</body>
</html>
