<!DOCTYPE html>
<html>
<body>

<?php
$a = 6;
$b = 6.70;
$c = "75";

var_dump($a);
echo "<br>";
var_dump($b);
echo "<br>";
var_dump($c);
?> 

<p>Line breaks were added for better readability.</p>

</body>
</html>