<!DOCTYPE html>
<html>

<body>

  <?php
  $t = 15;

  if ($t < 30) {
    echo "Betmut aku";
  }
  ?>

</body>

</html>