<!DOCTYPE html>
<html>
<body>

<?php
echo(round(10) . "<br>");
echo(round(50) . "<br>");
echo(round(39) . "<br>");
echo(round(-20) . "<br>");
echo(round(-90));
?>

</body>
</html>
