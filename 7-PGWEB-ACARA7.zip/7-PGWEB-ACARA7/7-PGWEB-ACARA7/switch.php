<!DOCTYPE html>
<html>

<body>

  <?php
  $favcolor = "pink";

  switch ($favcolor) {
    case "pink":
      echo "Warna kesukaan ku adalah pink!";
    case "hitam":
      echo "Warna kesukaan ku adalah hitam!";
      break;
    case "biru":
      echo "Warna kesukaan ku adalah biru!";
      break;
    default:
      echo "Warna kesukaan kamu adalah pink, hitam, biru !";
  }
  ?>

</body>

</html>