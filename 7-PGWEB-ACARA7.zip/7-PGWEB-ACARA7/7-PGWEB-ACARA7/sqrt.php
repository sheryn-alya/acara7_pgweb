<!DOCTYPE html>
<html>
<body>

<?php
echo(sqrt(400) . "<br>");
echo(sqrt(9) . "<br>");
echo(sqrt(-0.9) . "<br>");
echo(sqrt(9));
?>

</body>
</html>
