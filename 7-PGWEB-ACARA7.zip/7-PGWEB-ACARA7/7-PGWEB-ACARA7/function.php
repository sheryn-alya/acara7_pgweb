<!DOCTYPE html>
<html>
<body>

<?php
function familyName($fname, $year) {
  echo "$fname Refsnes. Kelahiran tahun $year <br>";
}

familyName("Jaemin","2000");
familyName("Jisung","2002");
familyName("Jaehyun","1997");
?>

</body>
</html>
