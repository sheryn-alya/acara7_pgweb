<!DOCTYPE html>
<html>

<body>

  <?php
  $t = date("H");
  echo "<p>Pesan di arsipkan " . $t;
  echo ", pesannya adalah</p>";

  if ($t < "10") {
    echo "Kamu apakabar?";
  } elseif ($t < "20") {
    echo "Udah makan belum?";
  } else {
    echo "Aku tidur dulu ya";
  }
  ?>

</body>

</html>