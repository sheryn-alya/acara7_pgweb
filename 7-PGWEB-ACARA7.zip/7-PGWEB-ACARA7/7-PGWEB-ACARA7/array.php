<!DOCTYPE html>
<html>
<body>
<pre>

<?php
$choice = array("Aku", "Kamu", "Dia"); 

var_dump($choice);
?>

</pre>
</body>
</html>